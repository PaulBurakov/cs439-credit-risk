"""
visualize.py
Credit Risk Project — All figures:
  - ROC curves (all models)
  - Confusion matrices
  - SHAP summary plot (XGBoost)
  - Feature importance (Random Forest)
  - PCA projection of K-Means clusters
  - Class distribution
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
import shap
from sklearn.metrics import roc_curve
from sklearn.decomposition import PCA
import warnings
warnings.filterwarnings("ignore")

PALETTE = ["#2563EB", "#16A34A", "#DC2626"]
FIG_DIR = "/home/claude/credit-risk-project/figures/"

import os
os.makedirs(FIG_DIR, exist_ok=True)


def plot_roc_curves(results, y_test, save=True):
    fig, ax = plt.subplots(figsize=(7, 5))
    for (name, res), color in zip(results.items(), PALETTE):
        fpr, tpr, _ = roc_curve(y_test, res["y_prob"])
        ax.plot(fpr, tpr, color=color, lw=2,
                label=f"{name} (AUC = {res['auc_roc']:.3f})")
    ax.plot([0, 1], [0, 1], "k--", lw=1, alpha=0.5)
    ax.set_xlabel("False Positive Rate", fontsize=12)
    ax.set_ylabel("True Positive Rate", fontsize=12)
    ax.set_title("ROC Curves — Credit Default Prediction", fontsize=14, fontweight="bold")
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    if save:
        fig.savefig(FIG_DIR + "roc_curves.png", dpi=150, bbox_inches="tight")
    print("    Saved: roc_curves.png")
    plt.close()


def plot_confusion_matrices(results, y_test, save=True):
    fig, axes = plt.subplots(1, 3, figsize=(14, 4))
    for ax, (name, res), color in zip(axes, results.items(), PALETTE):
        cm = res["cm"]
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax,
                    xticklabels=["No Default", "Default"],
                    yticklabels=["No Default", "Default"])
        ax.set_title(f"{name}", fontsize=11, fontweight="bold")
        ax.set_xlabel("Predicted")
        ax.set_ylabel("Actual")
    plt.suptitle("Confusion Matrices", fontsize=14, fontweight="bold", y=1.02)
    plt.tight_layout()
    if save:
        fig.savefig(FIG_DIR + "confusion_matrices.png", dpi=150, bbox_inches="tight")
    print("    Saved: confusion_matrices.png")
    plt.close()


def plot_shap(model, X_test, save=True):
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_test)
    # For binary classification, use class 1 (default)
    if isinstance(shap_values, list):
        sv = shap_values[1]
    else:
        sv = shap_values

    fig, ax = plt.subplots(figsize=(8, 6))
    shap.summary_plot(sv, X_test, plot_type="bar", show=False,
                      color="#2563EB", max_display=15)
    plt.title("SHAP Feature Importance — XGBoost", fontsize=14, fontweight="bold")
    plt.tight_layout()
    if save:
        fig.savefig(FIG_DIR + "shap_importance.png", dpi=150, bbox_inches="tight")
    print("    Saved: shap_importance.png")
    plt.close()


def plot_feature_importance(rf_model, feature_names, save=True):
    importances = rf_model.feature_importances_
    idx = np.argsort(importances)[-15:]
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.barh(range(len(idx)), importances[idx], color="#16A34A", edgecolor="white")
    ax.set_yticks(range(len(idx)))
    ax.set_yticklabels([feature_names[i] for i in idx], fontsize=9)
    ax.set_xlabel("Importance Score")
    ax.set_title("Top 15 Feature Importances — Random Forest", fontsize=13, fontweight="bold")
    ax.grid(True, axis="x", alpha=0.3)
    plt.tight_layout()
    if save:
        fig.savefig(FIG_DIR + "feature_importance.png", dpi=150, bbox_inches="tight")
    print("    Saved: feature_importance.png")
    plt.close()


def plot_pca_clusters(X_train, km_labels, save=True):
    pca = PCA(n_components=2, random_state=42)
    X_pca = pca.fit_transform(X_train.drop(columns=["cluster"], errors="ignore"))
    var = pca.explained_variance_ratio_

    fig, ax = plt.subplots(figsize=(7, 5))
    colors = ["#2563EB", "#16A34A", "#DC2626", "#D97706"]
    for k in np.unique(km_labels):
        mask = km_labels == k
        ax.scatter(X_pca[mask, 0], X_pca[mask, 1],
                   c=colors[k], label=f"Cluster {k}", alpha=0.5, s=20, edgecolors="none")
    ax.set_xlabel(f"PC1 ({var[0]:.1%} variance)", fontsize=11)
    ax.set_ylabel(f"PC2 ({var[1]:.1%} variance)", fontsize=11)
    ax.set_title("PCA Projection of K-Means Borrower Clusters", fontsize=13, fontweight="bold")
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    if save:
        fig.savefig(FIG_DIR + "pca_clusters.png", dpi=150, bbox_inches="tight")
    print("    Saved: pca_clusters.png")
    plt.close()


def plot_class_distribution(y_train, save=True):
    fig, ax = plt.subplots(figsize=(5, 4))
    counts = y_train.value_counts()
    ax.bar(["No Default (0)", "Default (1)"], counts.values,
           color=["#16A34A", "#DC2626"], edgecolor="white", width=0.5)
    for i, v in enumerate(counts.values):
        ax.text(i, v + 5, str(v), ha="center", fontweight="bold")
    ax.set_ylabel("Count")
    ax.set_title("Class Distribution (Training Set)", fontsize=13, fontweight="bold")
    ax.grid(True, axis="y", alpha=0.3)
    plt.tight_layout()
    if save:
        fig.savefig(FIG_DIR + "class_distribution.png", dpi=150, bbox_inches="tight")
    print("    Saved: class_distribution.png")
    plt.close()


def plot_metrics_comparison(results, save=True):
    names = list(results.keys())
    metrics = ["accuracy", "auc_roc", "f1"]
    labels = ["Accuracy", "AUC-ROC", "F1 Score"]
    x = np.arange(len(names))
    width = 0.25

    fig, ax = plt.subplots(figsize=(9, 5))
    for i, (metric, label) in enumerate(zip(metrics, labels)):
        vals = [results[n][metric] for n in names]
        bars = ax.bar(x + i * width, vals, width, label=label,
                      color=PALETTE[i], edgecolor="white")
        for bar, val in zip(bars, vals):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.005,
                    f"{val:.3f}", ha="center", va="bottom", fontsize=8)

    ax.set_xticks(x + width)
    ax.set_xticklabels(names, fontsize=10)
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("Score")
    ax.set_title("Model Performance Comparison", fontsize=13, fontweight="bold")
    ax.legend()
    ax.grid(True, axis="y", alpha=0.3)
    plt.tight_layout()
    if save:
        fig.savefig(FIG_DIR + "metrics_comparison.png", dpi=150, bbox_inches="tight")
    print("    Saved: metrics_comparison.png")
    plt.close()


if __name__ == "__main__":
    print("[5/5] Generating figures...")
    import sys
    sys.path.insert(0, "/home/claude/credit-risk-project/src")
    from preprocess import load_data, preprocess
    from train import train_models, add_cluster_features, evaluate

    df = load_data()
    X_train, X_test, y_train, y_test, feature_names, scaler = preprocess(df)
    X_train_c, X_test_c, km = add_cluster_features(X_train, X_test)
    models = train_models(X_train_c, y_train)
    results = evaluate(models, X_test_c, y_test)

    km_labels = km.predict(X_train_c.drop(columns=["cluster"], errors="ignore"))

    plot_class_distribution(y_train)
    plot_roc_curves(results, y_test)
    plot_confusion_matrices(results, y_test)
    plot_feature_importance(models["Random Forest"], X_train_c.columns.tolist())
    plot_shap(models["XGBoost"], X_test_c)
    plot_pca_clusters(X_train_c, X_train_c["cluster"].values)
    plot_metrics_comparison(results)

    print("All figures saved.")
